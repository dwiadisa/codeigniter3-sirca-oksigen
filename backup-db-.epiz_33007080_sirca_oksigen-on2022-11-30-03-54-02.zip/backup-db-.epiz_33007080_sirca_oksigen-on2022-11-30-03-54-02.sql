SET foreign_key_checks = 0;
#
# TABLE STRUCTURE FOR: data_ca
#

DROP TABLE IF EXISTS `data_ca`;

CREATE TABLE `data_ca` (
  `id_ca` int(11) NOT NULL AUTO_INCREMENT,
  `no_induk_CA` varchar(50) CHARACTER SET utf8mb4 NOT NULL,
  `pengguna_nama` varchar(60) CHARACTER SET utf8mb4 NOT NULL,
  `pengguna_username` varchar(50) NOT NULL,
  `pengguna_password` varchar(250) NOT NULL,
  `pengguna_email` varchar(250) NOT NULL,
  `pengguna_level` enum('WTO_ADMIN','WTO_VIEW','CALON_ANGGOTA','') NOT NULL,
  `pengguna_status` int(11) NOT NULL,
  `nim` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
  `fakultas` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
  `prodi` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
  `jenis_kelamin` varchar(12) NOT NULL,
  `tempat_lahir` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat_rumah` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `alamat_kost` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `instagram` varchar(50) CHARACTER SET utf8mb4 NOT NULL,
  `no_hp` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
  `hobi` varchar(250) CHARACTER SET utf8mb4 NOT NULL,
  `div_drama` int(11) NOT NULL,
  `div_tari` int(11) NOT NULL,
  `div_rupa` int(11) NOT NULL,
  `div_sinema` int(11) NOT NULL,
  `alasan` longtext CHARACTER SET utf8mb4 NOT NULL,
  `riwayat_organisasi` longtext CHARACTER SET utf8mb4 NOT NULL,
  `foto_ktm` varchar(500) NOT NULL,
  `foto_diri` varchar(500) NOT NULL,
  `tanggal_submit` date NOT NULL,
  `tahun_submit` year(4) NOT NULL,
  PRIMARY KEY (`id_ca`),
  UNIQUE KEY `pengguna_username` (`pengguna_username`),
  UNIQUE KEY `pengguna_email` (`pengguna_email`)
) ENGINE=InnoDB AUTO_INCREMENT=219 DEFAULT CHARSET=armscii8;

INSERT INTO `data_ca` (`id_ca`, `no_induk_CA`, `pengguna_nama`, `pengguna_username`, `pengguna_password`, `pengguna_email`, `pengguna_level`, `pengguna_status`, `nim`, `fakultas`, `prodi`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_kost`, `instagram`, `no_hp`, `hobi`, `div_drama`, `div_tari`, `div_rupa`, `div_sinema`, `alasan`, `riwayat_organisasi`, `foto_ktm`, `foto_diri`, `tanggal_submit`, `tahun_submit`) VALUES (156, 'CATO-2022-1810651078', 'Farel Mistoasdasd', 'farel_misto', '25d55ad283aa400af464c76d713c07ad', 'farelfaraday234@gmail.com', 'CALON_ANGGOTA', 1, '1810651078', '1', '1', 'Laki-Laki', 'Malang', '2022-11-23', 'hjgjgjhgjhghjgjhgjhgjhgjh', 'hjhghjghjgjhgjhgjh', '@adasdsad', '8090909009090', 'menek pager', 1, 1, 1, 1, 'nambah kenalan cewek ajah seh gak macem macem', '                test test test', 'null_ktm.png', 'asu.png', '2022-11-12', '2020');
INSERT INTO `data_ca` (`id_ca`, `no_induk_CA`, `pengguna_nama`, `pengguna_username`, `pengguna_password`, `pengguna_email`, `pengguna_level`, `pengguna_status`, `nim`, `fakultas`, `prodi`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_kost`, `instagram`, `no_hp`, `hobi`, `div_drama`, `div_tari`, `div_rupa`, `div_sinema`, `alasan`, `riwayat_organisasi`, `foto_ktm`, `foto_diri`, `tanggal_submit`, `tahun_submit`) VALUES (157, 'CATO-2022-1231221', 'SIRCA TEST', 'calon_anggota2', '25d55ad283aa400af464c76d713c07ad', 'emailkuaja@email.com', 'CALON_ANGGOTA', 1, '18130651072', '1', '3', 'Laki-Laki', 'Malang', '2021-12-31', 'askdlksajdlkjaslkdjsalkdjla', 'kjashdkjahsjkdhsakjhdkja', '@adasdsad', '00000000', 'askdjklasjdlkasjd', 1, 1, 1, 1, 'jkshjhkjhakjd', '      jskdfjshkfjhskjfhs', 'null_ktm.png', 'logo_web_o2.png', '2022-11-19', '0000');
INSERT INTO `data_ca` (`id_ca`, `no_induk_CA`, `pengguna_nama`, `pengguna_username`, `pengguna_password`, `pengguna_email`, `pengguna_level`, `pengguna_status`, `nim`, `fakultas`, `prodi`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_kost`, `instagram`, `no_hp`, `hobi`, `div_drama`, `div_tari`, `div_rupa`, `div_sinema`, `alasan`, `riwayat_organisasi`, `foto_ktm`, `foto_diri`, `tanggal_submit`, `tahun_submit`) VALUES (181, '', 'test calon calon', 'test_calon_oksigen', '25d55ad283aa400af464c76d713c07ad', 'test_calon_oksigen@email.go.id', 'CALON_ANGGOTA', 1, '', '', '', '', '', '0000-00-00', '', '', '', '', '', 0, 0, 0, 0, '', '', '', 'null_foto.jpg', '0000-00-00', '0000');
INSERT INTO `data_ca` (`id_ca`, `no_induk_CA`, `pengguna_nama`, `pengguna_username`, `pengguna_password`, `pengguna_email`, `pengguna_level`, `pengguna_status`, `nim`, `fakultas`, `prodi`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_kost`, `instagram`, `no_hp`, `hobi`, `div_drama`, `div_tari`, `div_rupa`, `div_sinema`, `alasan`, `riwayat_organisasi`, `foto_ktm`, `foto_diri`, `tanggal_submit`, `tahun_submit`) VALUES (182, 'CATO-2022-9999999999999', 'asdasdasd', 'calonanggota2000', '25d55ad283aa400af464c76d713c07ad', 'emailnyaca@email.com', 'CALON_ANGGOTA', 1, '9999999999999', '4', '14', 'Perempuan', 'wqeqwewqewqe', '2022-11-23', 'ewtfwerewr', 'ewrewrewrewrewrew', 'wqewqe', '00000000', 'ewrewrewr', 1, 1, 0, 0, 'asd', '            ewrewrewrewrewrewr', 'null_ktm.png', 'null_foto.jpg', '2022-11-23', '2022');
INSERT INTO `data_ca` (`id_ca`, `no_induk_CA`, `pengguna_nama`, `pengguna_username`, `pengguna_password`, `pengguna_email`, `pengguna_level`, `pengguna_status`, `nim`, `fakultas`, `prodi`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_kost`, `instagram`, `no_hp`, `hobi`, `div_drama`, `div_tari`, `div_rupa`, `div_sinema`, `alasan`, `riwayat_organisasi`, `foto_ktm`, `foto_diri`, `tanggal_submit`, `tahun_submit`) VALUES (207, 'CATO-2022-1856554785', 'ukm teater oksigen', 'ukmteateroksigen', '25d55ad283aa400af464c76d713c07ad', 'ukmteateroksigen@email.id', 'CALON_ANGGOTA', 1, '1856554785', '7', '19', 'Laki-Laki', 'sadsadsadsadsa', '2022-11-08', 'sadasdsadsad', 'sadsadas', 'dsadsadas', 'asdasd', 'sadsadas', 0, 0, 1, 1, 'sadasdas', '    asdasdas', 'null_ktm.png', 'null_foto.jpg', '2022-11-23', '2022');
INSERT INTO `data_ca` (`id_ca`, `no_induk_CA`, `pengguna_nama`, `pengguna_username`, `pengguna_password`, `pengguna_email`, `pengguna_level`, `pengguna_status`, `nim`, `fakultas`, `prodi`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_kost`, `instagram`, `no_hp`, `hobi`, `div_drama`, `div_tari`, `div_rupa`, `div_sinema`, `alasan`, `riwayat_organisasi`, `foto_ktm`, `foto_diri`, `tanggal_submit`, `tahun_submit`) VALUES (208, '', 'asdasdas', '', '', '', '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', '', 0, 0, 0, 0, '', '', '', '', '0000-00-00', '0000');
INSERT INTO `data_ca` (`id_ca`, `no_induk_CA`, `pengguna_nama`, `pengguna_username`, `pengguna_password`, `pengguna_email`, `pengguna_level`, `pengguna_status`, `nim`, `fakultas`, `prodi`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_kost`, `instagram`, `no_hp`, `hobi`, `div_drama`, `div_tari`, `div_rupa`, `div_sinema`, `alasan`, `riwayat_organisasi`, `foto_ktm`, `foto_diri`, `tanggal_submit`, `tahun_submit`) VALUES (210, 'CATO-2022-787987979', 'test aja dah', 'cuma_kamu', '25d55ad283aa400af464c76d713c07ad', 'cuma_kau@email.com', 'CALON_ANGGOTA', 1, '787987979', '1', '3', 'Laki-Laki', 'kjkjhkhkhkjh', '2022-11-17', 'sadsadasda', 'sadasdsadsadas', 'asudhagdjha', '21321321', 'sadasdasdsad', 0, 0, 0, 1, 'sadsadasd', 'asdsadsadasd', 'null_ktm.png', 'PHP.jpg', '2022-11-20', '2022');
INSERT INTO `data_ca` (`id_ca`, `no_induk_CA`, `pengguna_nama`, `pengguna_username`, `pengguna_password`, `pengguna_email`, `pengguna_level`, `pengguna_status`, `nim`, `fakultas`, `prodi`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_kost`, `instagram`, `no_hp`, `hobi`, `div_drama`, `div_tari`, `div_rupa`, `div_sinema`, `alasan`, `riwayat_organisasi`, `foto_ktm`, `foto_diri`, `tanggal_submit`, `tahun_submit`) VALUES (211, 'CATO-2022-78798797987', 'adisamedia developer', 'suka_aja_daftar', '25d55ad283aa400af464c76d713c07ad', 'suka_aja_daftar@email.com', 'CALON_ANGGOTA', 1, '78798797987', '4', '14', 'Laki-Laki', 'Lumajang', '1998-03-23', 'Jl. Singosari 45 Jember Kaliwates', '-', '@adasdsad', '00000000', 'balapa liar di jalanan yang berliku', 1, 0, 0, 1, 'suka aja iseng maen maen aja ', 'ketua umum drag and drop', 'null_ktm.png', 'IMG_4807.jpg', '2022-11-23', '2022');
INSERT INTO `data_ca` (`id_ca`, `no_induk_CA`, `pengguna_nama`, `pengguna_username`, `pengguna_password`, `pengguna_email`, `pengguna_level`, `pengguna_status`, `nim`, `fakultas`, `prodi`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_kost`, `instagram`, `no_hp`, `hobi`, `div_drama`, `div_tari`, `div_rupa`, `div_sinema`, `alasan`, `riwayat_organisasi`, `foto_ktm`, `foto_diri`, `tanggal_submit`, `tahun_submit`) VALUES (212, 'CATO-2022-987654321', 'Sandhika Galih', 'sandhika_ca', 'ef17ed4b3d6784e012db7de242793335', 'sandhikagalih_ca@gmail.com', 'CALON_ANGGOTA', 1, '987654321', '1', '1', 'Laki-Laki', 'Bandung', '1989-02-25', 'Bandung Raya', 'Tidak Kost', '@sandhikagalih', '08000000000', 'ngoding ', 1, 1, 1, 1, 'Jenuh dengan kodingan, pengen nyoba seni ajah ', 'Dosen UNPAS', 'null_ktm.png', 'Sandhika-Galih1.jpg', '2022-11-24', '2022');
INSERT INTO `data_ca` (`id_ca`, `no_induk_CA`, `pengguna_nama`, `pengguna_username`, `pengguna_password`, `pengguna_email`, `pengguna_level`, `pengguna_status`, `nim`, `fakultas`, `prodi`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_kost`, `instagram`, `no_hp`, `hobi`, `div_drama`, `div_tari`, `div_rupa`, `div_sinema`, `alasan`, `riwayat_organisasi`, `foto_ktm`, `foto_diri`, `tanggal_submit`, `tahun_submit`) VALUES (214, 'CATO-2022-2211011155', 'Tri Amanda Aurielia Zalsabila S ', 'TriAmandaAurieliaZalsabilaS ', '25d55ad283aa400af464c76d713c07ad', 'triamandaaurelia@gmail.com', 'CALON_ANGGOTA', 1, '2211011155', '4', '31', 'Perempuan', 'Jember ', '2003-07-04', 'Jalan KH Agus Salim no 38 Tegal besar Kaliwates Jember ', '-', 'trisanabilaa_', '0821-4145-8442', 'Tari', 0, 1, 1, 0, 'Karna ingin bergabung dengan pecinta kesenian dan melestarikan tari tradisional ', 'Osis,PMR,Ekstra Tari Tradisional ', 'null_ktm.png', 'IMG_0058_-_Tri_Amanda_Aurelia.JPG', '2022-11-30', '2022');
INSERT INTO `data_ca` (`id_ca`, `no_induk_CA`, `pengguna_nama`, `pengguna_username`, `pengguna_password`, `pengguna_email`, `pengguna_level`, `pengguna_status`, `nim`, `fakultas`, `prodi`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_kost`, `instagram`, `no_hp`, `hobi`, `div_drama`, `div_tari`, `div_rupa`, `div_sinema`, `alasan`, `riwayat_organisasi`, `foto_ktm`, `foto_diri`, `tanggal_submit`, `tahun_submit`) VALUES (215, 'CATO-2022-2110211027', 'Vizza Az zahra Al laros', 'VizzaAzzahraAllaros', '25d55ad283aa400af464c76d713c07ad', 'Vizzaazzahra7@gmail.com', 'CALON_ANGGOTA', 1, '2110211027', '7', '29', 'Perempuan', 'Tangerang', '2004-05-21', 'Dsn perangan Rt 02 Rw 04, Ds Kradenan, Kec Purwoharjo, Kab Banyuwangi', 'Kost Direva, Jln karimata gang madya 01', 'oneofpijaaa', '085816128949', 'Menari', 0, 1, 0, 0, 'Alasan mengikuti ukm teater ini untuk menemukan jati diri serta mengembangkan minat dan bakat untuk kedepannya dan melestarikan budaya indonesia', ' Mengikuti HMPManihootglaziovi ', 'null_ktm.png', 'WhatsApp_Image_2022-09-07_at_14_40_00_-_Vizza_Az_zahra.jpeg', '2022-11-30', '2022');
INSERT INTO `data_ca` (`id_ca`, `no_induk_CA`, `pengguna_nama`, `pengguna_username`, `pengguna_password`, `pengguna_email`, `pengguna_level`, `pengguna_status`, `nim`, `fakultas`, `prodi`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_kost`, `instagram`, `no_hp`, `hobi`, `div_drama`, `div_tari`, `div_rupa`, `div_sinema`, `alasan`, `riwayat_organisasi`, `foto_ktm`, `foto_diri`, `tanggal_submit`, `tahun_submit`) VALUES (216, 'CATO-2022-2211011036', 'Yuli Suci Andarini ', 'yulisuciandarini2', '25d55ad283aa400af464c76d713c07ad', 'yulisuciandarini2@gmail.com', 'CALON_ANGGOTA', 1, '2211011036', '4', '31', 'Perempuan', 'Bondowoso ', '2004-07-07', 'Maskuning kulon, Kec.Pujer, Kab.Bondowoso', 'Jl.Karimata', 'ylisciandrnii', '082136408862', 'Tari modern', 0, 1, 0, 0, 'Ingin mengembangkan bakat saya di bidang seni khususnya seni tari ', 'OSIS, PRAMUKA, PMR, EKSTRA TARI', 'null_ktm.png', 'null_foto.jpg', '2022-11-30', '2022');
INSERT INTO `data_ca` (`id_ca`, `no_induk_CA`, `pengguna_nama`, `pengguna_username`, `pengguna_password`, `pengguna_email`, `pengguna_level`, `pengguna_status`, `nim`, `fakultas`, `prodi`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_kost`, `instagram`, `no_hp`, `hobi`, `div_drama`, `div_tari`, `div_rupa`, `div_sinema`, `alasan`, `riwayat_organisasi`, `foto_ktm`, `foto_diri`, `tanggal_submit`, `tahun_submit`) VALUES (217, 'CATO-2022-2211011152', 'devi agustinu rahayu', 'agustinirahayudevi', '25d55ad283aa400af464c76d713c07ad', 'agustinirahayudevi@gmail.com', 'CALON_ANGGOTA', 1, '2211011152', '4', '31', 'Perempuan', 'cianjur', '2004-08-17', 'perumahan istana kaliwates jember', 'perumahan istana kaliwates jember', 'deviarahayuu', '087753888580', 'masih tahap mencari kak di ukm ini', 0, 1, 0, 0, 'karna dulu SMK pernah mengikuti ekstra nari meskipun hanya sebentar dan ingin mencari bakat di ukm ini', ' dewan ambalan (smp) , osis selama kurang dari satu periode (smk)', 'null_ktm.png', 'D9B92CC2-A869-4EB4-A30E-3498F49E1EC7_-_Nabila_Septa.jpeg', '2022-11-30', '2022');
INSERT INTO `data_ca` (`id_ca`, `no_induk_CA`, `pengguna_nama`, `pengguna_username`, `pengguna_password`, `pengguna_email`, `pengguna_level`, `pengguna_status`, `nim`, `fakultas`, `prodi`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_kost`, `instagram`, `no_hp`, `hobi`, `div_drama`, `div_tari`, `div_rupa`, `div_sinema`, `alasan`, `riwayat_organisasi`, `foto_ktm`, `foto_diri`, `tanggal_submit`, `tahun_submit`) VALUES (218, 'CATO-2022-2210411064', 'Wahdiati Zaen ', 'wahdiatizaen', '25d55ad283aa400af464c76d713c07ad', 'wahdiatizaen@gmail.com', 'CALON_ANGGOTA', 1, '2210411064', '10', '10', 'Perempuan', 'Jember', '2004-05-13', 'Wringinanung Jombang Jember ', 'Jalan karimata IV', 'wahdiati_', '081249248626', '-', 0, 1, 0, 0, 'Karena suka tari tradisional ', ' Tari', 'null_ktm.png', 'null_foto.jpg', '2022-11-30', '2022');


#
# TABLE STRUCTURE FOR: data_fakultas
#

DROP TABLE IF EXISTS `data_fakultas`;

CREATE TABLE `data_fakultas` (
  `id_fakultas` int(11) NOT NULL AUTO_INCREMENT,
  `nama_fakultas` varchar(50) NOT NULL,
  PRIMARY KEY (`id_fakultas`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;

INSERT INTO `data_fakultas` (`id_fakultas`, `nama_fakultas`) VALUES (1, 'Teknik');
INSERT INTO `data_fakultas` (`id_fakultas`, `nama_fakultas`) VALUES (2, 'Hukum');
INSERT INTO `data_fakultas` (`id_fakultas`, `nama_fakultas`) VALUES (3, 'Ilmu Sosial dan Politik');
INSERT INTO `data_fakultas` (`id_fakultas`, `nama_fakultas`) VALUES (4, 'Ilmu Kesehatan');
INSERT INTO `data_fakultas` (`id_fakultas`, `nama_fakultas`) VALUES (5, 'Psikologi');
INSERT INTO `data_fakultas` (`id_fakultas`, `nama_fakultas`) VALUES (7, 'Ilmu Keguruan dan Ilmu Pendidikan');
INSERT INTO `data_fakultas` (`id_fakultas`, `nama_fakultas`) VALUES (10, 'Ekonomi dan Bisnis');
INSERT INTO `data_fakultas` (`id_fakultas`, `nama_fakultas`) VALUES (11, ' Agama Islam');
INSERT INTO `data_fakultas` (`id_fakultas`, `nama_fakultas`) VALUES (12, 'Pertanian');


#
# TABLE STRUCTURE FOR: data_prodi
#

DROP TABLE IF EXISTS `data_prodi`;

CREATE TABLE `data_prodi` (
  `id_prodi` int(11) NOT NULL AUTO_INCREMENT,
  `nama_prodi` varchar(50) NOT NULL,
  `fakultas` int(11) NOT NULL,
  PRIMARY KEY (`id_prodi`),
  KEY `fk_fakultas_ke_prodi` (`fakultas`),
  CONSTRAINT `fk_fakultas_ke_prodi` FOREIGN KEY (`fakultas`) REFERENCES `data_fakultas` (`id_fakultas`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4;

INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (1, 'Teknik Informatika', 1);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (2, 'Teknik Sipil', 1);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (3, 'Teknik Lingkungan', 1);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (4, 'Manajemen Informatika', 1);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (5, 'Teknik Mesin', 1);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (6, 'Ilmu Komunikasi', 3);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (7, 'Ilmu Pemerintahan', 3);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (8, 'Ilmu Hukum', 2);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (9, 'Psikologi', 5);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (10, 'Manajemen', 10);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (12, 'Akuntansi', 10);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (14, 'Keperawatan', 4);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (19, 'Pendidikan Bahasa dan Sastra Indonesia', 7);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (20, 'Pendidikan Bahasa Inggris', 7);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (21, 'Matematika', 7);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (23, 'Pendidikan Agama Islam', 11);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (24, 'Ekonomi Syariah', 11);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (25, 'Agroteknologi', 12);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (26, 'Pendidikan Olahraga', 7);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (27, 'Teknik Elektro', 1);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (28, 'Teknologi Ilmu Pertanian', 12);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (29, 'Pendidikan Biologi', 7);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (30, 'Perhotelan D3', 3);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (31, 'S1 Keperawatan', 4);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (32, 'Ners Keperawatan', 4);
INSERT INTO `data_prodi` (`id_prodi`, `nama_prodi`, `fakultas`) VALUES (34, 'aaaaaaaaaaaaaa', 3);


#
# TABLE STRUCTURE FOR: pengguna
#

DROP TABLE IF EXISTS `pengguna`;

CREATE TABLE `pengguna` (
  `id_pengguna` int(11) NOT NULL AUTO_INCREMENT,
  `pengguna_nama` varchar(50) NOT NULL,
  `pengguna_username` varchar(50) NOT NULL,
  `pengguna_password` varchar(250) NOT NULL,
  `pengguna_email` varchar(250) NOT NULL,
  `pengguna_level` enum('WTO_ADMIN','WTO_VIEW','KEANGGOTAAN','') NOT NULL,
  `pengguna_foto` varchar(255) NOT NULL,
  `pengguna_status` int(11) NOT NULL,
  PRIMARY KEY (`id_pengguna`),
  UNIQUE KEY `pengguna_username` (`pengguna_username`),
  UNIQUE KEY `pengguna_email` (`pengguna_email`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4;

INSERT INTO `pengguna` (`id_pengguna`, `pengguna_nama`, `pengguna_username`, `pengguna_password`, `pengguna_email`, `pengguna_level`, `pengguna_foto`, `pengguna_status`) VALUES (1, 'Arrohim Dwi Ksatria', '11.18.10', '21232f297a57a5a743894a0e4a801fc3', 'admin@email.net', 'WTO_ADMIN', 'IMG_4807.jpg', 1);
INSERT INTO `pengguna` (`id_pengguna`, `pengguna_nama`, `pengguna_username`, `pengguna_password`, `pengguna_email`, `pengguna_level`, `pengguna_foto`, `pengguna_status`) VALUES (32, 'test admin', '11.18.99', '25d55ad283aa400af464c76d713c07ad', 'farelfaraday234@gmail.com', 'WTO_ADMIN', 'IMG_7008_(1).jpg', 1);
INSERT INTO `pengguna` (`id_pengguna`, `pengguna_nama`, `pengguna_username`, `pengguna_password`, `pengguna_email`, `pengguna_level`, `pengguna_foto`, `pengguna_status`) VALUES (34, 'TEST WTO VIEW', 'testwtoview', '25d55ad283aa400af464c76d713c07ad', 'testwtoview@email.om', 'WTO_VIEW', 'PHP.jpg', 1);
INSERT INTO `pengguna` (`id_pengguna`, `pengguna_nama`, `pengguna_username`, `pengguna_password`, `pengguna_email`, `pengguna_level`, `pengguna_foto`, `pengguna_status`) VALUES (35, 'Safitri Ramadhayanti Saputro', '14.21.08', '25d55ad283aa400af464c76d713c07ad', 'safitri@email.com', 'WTO_VIEW', 'logo_adisa.png', 1);
INSERT INTO `pengguna` (`id_pengguna`, `pengguna_nama`, `pengguna_username`, `pengguna_password`, `pengguna_email`, `pengguna_level`, `pengguna_foto`, `pengguna_status`) VALUES (39, 'Sandhika Galih ADMIN', 'sandhika_admin', 'ef17ed4b3d6784e012db7de242793335', 'sandhikagalih@gmail.com', 'WTO_ADMIN', 'tKGooqvh_400x4001.jpg', 1);
INSERT INTO `pengguna` (`id_pengguna`, `pengguna_nama`, `pengguna_username`, `pengguna_password`, `pengguna_email`, `pengguna_level`, `pengguna_foto`, `pengguna_status`) VALUES (40, 'Sandhika Galih VIEW', 'sandhika_view', 'ef17ed4b3d6784e012db7de242793335', 'sandhikagalih_view@gmail.com', 'WTO_VIEW', 'SANDHIKA-GALIH-1024x6821.jpeg', 1);


#
# TABLE STRUCTURE FOR: setting
#

DROP TABLE IF EXISTS `setting`;

CREATE TABLE `setting` (
  `id_setting` int(11) NOT NULL,
  `nama_setting` varchar(10) NOT NULL,
  `value` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_setting`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

INSERT INTO `setting` (`id_setting`, `nama_setting`, `value`) VALUES (0, 'form_aktif', 0);


#
# TABLE STRUCTURE FOR: side_bar
#

DROP TABLE IF EXISTS `side_bar`;

CREATE TABLE `side_bar` (
  `id_menu` int(11) NOT NULL AUTO_INCREMENT,
  `icon` varchar(100) NOT NULL,
  `text` varchar(100) NOT NULL,
  `link` varchar(100) NOT NULL,
  `category` enum('Content Management System','SISTEM PENDAFTARAN CALON ANGGOTA','SETTING','') NOT NULL,
  `hak_akses` enum('a','','','') NOT NULL,
  PRIMARY KEY (`id_menu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET foreign_key_checks = 1;
